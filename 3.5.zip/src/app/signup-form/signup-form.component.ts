import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';

@Component({
  selector: 'app-signup-form',
  templateUrl: './signup-form.component.html',
  styleUrls: ['./signup-form.component.css']
})
export class SignupFormComponent implements OnInit {
  form: FormGroup;

  constructor(builder: FormBuilder) {
    this.form = builder.group({
      username: 'adri',
      email: 'adri91@gmail.com',
      password: 'ciao123',
    });
  }

  ngOnInit(): void {
  }

  onSubmit(form: any) {
    console.log({form});
  }
}

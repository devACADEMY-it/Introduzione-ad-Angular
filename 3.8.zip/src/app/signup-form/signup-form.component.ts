import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';

function passwordValidator(control: FormControl): { [s: string]: boolean } {
  if (!control.value.match(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{8,}$/)) {
    return { invalidPassword: true };
  }
}

@Component({
  selector: 'app-signup-form',
  templateUrl: './signup-form.component.html',
  styleUrls: ['./signup-form.component.css']
})
export class SignupFormComponent implements OnInit {
  name: string;
  form: FormGroup;

  constructor(builder: FormBuilder) {
    this.name = '';
    this.form = builder.group({
      username: ['', Validators.required],
      email: ['', Validators.required],
      password: ['', Validators.compose([Validators.required, passwordValidator])],
    });
  }

  ngOnInit(): void {
  }

  onSubmit(form: any) {
    console.log({form});
  }
}

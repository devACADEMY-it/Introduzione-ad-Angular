import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-todo-form',
  templateUrl: './add-todo-form.component.html',
  styleUrls: ['./add-todo-form.component.css']
})
export class AddTodoFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  onAddTask(desc, priority) {
    console.log('desc', desc.value);
    console.log('priority', priority.value);
  }

}
